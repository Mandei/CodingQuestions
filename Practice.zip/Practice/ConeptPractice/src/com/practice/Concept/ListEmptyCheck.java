package com.practice.Concept;

import java.util.*;

public class ListEmptyCheck {
	
	public static void main(String[] args) 
	{
		
		List<String> data1=new ArrayList<>();
		List<Integer> data2 = new ArrayList<>();;
//		data1.add("Mandy");
//		data2.add(50);
		
		List data=new ArrayList();
		data.add(data1);
		data.add(data2);
		
		List result=data ;
		
		if((result.get(0)) instanceof List)
			System.out.println("List TYpe");
		
		if(((List)result.get(1)).isEmpty())
			System.out.println("EmptyList");
		else
			System.out.println("Not Empty List");
		
		System.out.println(result);
		
	}
	
}
