package com.practice.Concept;
import java.util.*;

public class BalanceParenthesis {

	public static void main(String[] args) {
		String exp="]{{}}";
		Stack<Character> s= new Stack<Character>();
		
		boolean flag=true;
		for(int i=0;i<exp.length();i++)
		{

			
			if((exp.charAt(i)=='{') || (exp.charAt(i)=='(') || (exp.charAt(i)=='['))
				s.push(exp.charAt(i));
			
			if(s.isEmpty()) 
			{
				flag=false;
				break;
			}
			
			if(exp.charAt(i)=='}') 
				{
					if(s.peek()=='{')
						s.pop();
					else
					{
					 flag=false;
					 break;
					}
				}
			if(exp.charAt(i)==']') 
			{
				if(s.peek()=='[')
					s.pop();
				else
				{
				 flag=false;
				 break;
				}
			}	
			if(exp.charAt(i)==')') 
			{
				if(s.peek()=='(')
					s.pop();
				else
				{
				 flag=false;
				 break;
				}
			}	
			
		}
			
		
		if(!(s.isEmpty()) && !flag)
			System.out.println("Invalid Expression");
		else
			System.out.println("Valid Expression");
			
		
	}
}
