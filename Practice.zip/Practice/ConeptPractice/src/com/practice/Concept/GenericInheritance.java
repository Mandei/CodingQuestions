package com.practice.Concept;

import java.util.*;
class a{
	
}

class b extends a{
	
}

public class GenericInheritance {
	
	public static void main(String[] args) 
	{
//		List<b> list=new ArrayList<a>();
		
		
	}
	
}
