package com.practice.Concept;

import java.util.ArrayList;
import java.util.List;



public class StringArrayPractice {

	static List<double[]> resultArray = new ArrayList<>();
	
	public static void main(String[] args) 
	{
		List<String> col=new ArrayList<>();
		for(int i=0;i<6;i++)
			col.add("Rate-"+(i+1));
		
		String column[]=col.toArray(new String[0]);
		for(int i=0;i<6;i++)
			System.out.println(column[i]);
		
		double[]result1= {0,1,2,3,4,5};
		double[]result2= {7,1,2,3,4,5};
		resultArray.add(result2);
		resultArray.add(result1);
		
		
		String resultSet[][]=new String[resultArray.size()][];
		
		for(int i=0;i<resultArray.size();i++) {
			resultSet[i]=covertToStringArray(resultArray.get(0));
		}
		
		for(int i=0;i<resultSet.length;i++) {
			for(int j=0;j<resultSet[i].length;j++) 
			System.out.println(resultSet[i][j]);
		}
		
		
		
	}
	static String[] covertToStringArray(double[] val) 
	{
	String[] result=new String[val.length];
	for(int i=0;i<val.length;i++)
		result[i]=Double.toString(val[i]);
	return result;
	}
	
}
