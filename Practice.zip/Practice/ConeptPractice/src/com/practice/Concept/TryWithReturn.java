package com.practice.Concept;

public class TryWithReturn {

	public static void main(String[] args) {
		
		System.out.println(m1());;
		
	}
	
	static int m1()
	{
		try {
			System.out.println("Try");
			int a=10/0;
			return 777;
			
		}
		catch(ArithmeticException e)
		{
			System.out.println("Exception");
			return 888;
		}
		finally {
			System.out.println("Finally");
			return 999;
		}
	}
}
