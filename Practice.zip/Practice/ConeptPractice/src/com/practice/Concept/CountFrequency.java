package com.practice.Concept;

import java.util.*;

public class CountFrequency {

	public static void main(String[] args) {
		Map<Character,Integer> map=new TreeMap<>();
		String s="I am a Java developer";
				
		for(int i=0;i<s.length();i++)
		{
			if(map.containsKey(s.charAt(i)))
				map.put(s.charAt(i), map.get(s.charAt(i))+1);
			else
				map.put(s.charAt(i), 1);
		
		}
		System.out.println(map);
					
		
	}
}
