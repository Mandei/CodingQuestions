package com.practice.Concept;

import java.util.*;

public class PracticeTreeLikeStructure {

	public static void main(String[] args) {
		List<Map<String, String>> properties = new ArrayList<>();

		Map<String, String> property1 = new HashMap<>();
		property1.put("AMDF_EXT_ID", "126");
		property1.put("ANSY_NAME", "AS_1");
		property1.put("AMPO_LABL", "Port3 ");
		property1.put("Data", "Valid");

		properties.add(property1);

		Map<String, String> property2 = new HashMap<>();
		property2.put("AMDF_EXT_ID", "127");
		property2.put("ANSY_NAME", "AS_1");
		property2.put("AMPO_LABL", "Port4");
		property2.put("AMPL_FREQ", "500");
		property2.put("AMPL_LOSS", "23");
		

		properties.add(property2);

		Map<String, String> property3 = new HashMap<>();
		property3.put("AMDF_EXT_ID", "127");
		property3.put("ANSY_NAME", "AS_3");
		property3.put("AMPO_LABL", "Port3");
		property3.put("Data", "Valid");

		properties.add(property3);

		Map<String, PropertyVO> propertyMap = new HashMap<>();

		
		
		// To be used in Office Project -> Java
		for (Map<String, String> rs : properties) {

			String extId = rs.get("AMDF_EXT_ID");
			PropertyVO protocol = null;
			if (propertyMap.containsKey(extId)) 
			{
				protocol = propertyMap.get(extId);
			} 
			else if(!extId.isBlank())
			{
				protocol = new PropertyVO();
				protocol.setPropertyId(extId);
				propertyMap.put(protocol.getPropertyId(), protocol);
			}
			
			

			String antennaName = rs.get("ANSY_NAME");
			PropertyVO antenna = null;
			if (protocol!=null && protocol.getChildProperties() != null) 
			{
				for (Map<String, PropertyVO> childData : protocol.getChildProperties()) 
				{
					if (childData.containsKey(antennaName)) 
					{
						antenna = childData.get(antennaName);
					}
				}
			}
			if ( protocol!=null && antenna == null && !antennaName.isBlank() ) 
			{
				antenna = new PropertyVO();
				antenna.setPropertyId(antennaName);

				List<Map<String, PropertyVO>> antList = new ArrayList<>();
				Map<String, PropertyVO> antMap = new HashMap<>();
				
				antMap.put(antenna.getPropertyId(), antenna);

				if (protocol.getChildProperties() != null)
					antList = protocol.getChildProperties();

				antList.add(antMap);
				protocol.setChildProperties(antList);
			}

			
			
			
			String portName = rs.get("AMPO_LABL");
			PropertyVO port = null;
			if (antenna!=null && antenna.getChildProperties() != null)
			{
				for (Map<String, PropertyVO> childData : antenna.getChildProperties()) {
					if (childData.containsKey(portName)) {
						port = childData.get(portName);
					}
				}
			}

			if (antenna!=null && port == null  && !portName.isBlank()) 
			{
				port = new PropertyVO();
				port.setPropertyId(portName);

				List<Map<String, PropertyVO>> portList = new ArrayList<>();
				Map<String, PropertyVO> portMap = new HashMap<>();
				
				portMap.put(port.getPropertyId(), port);

				if (antenna.getChildProperties() != null)
					portList = antenna.getChildProperties();

				portList.add(portMap);
				antenna.setChildProperties(portList);
			}
			
			
			
			
			String frequency = rs.get("AMPL_FREQ");
			String loss=rs.get("AMPL_LOSS");
			PropertyVO freq = null;
			if (port!=null && port.getChildProperties() != null)
			{
				for (Map<String, PropertyVO> childData : port.getChildProperties()) {
					if (childData.containsKey(frequency)) {
						port = childData.get(frequency);
					}
				}
			}

			if (port!=null && freq == null  && frequency!=null && !frequency.isBlank() && loss!=null && !loss.isBlank()) 
			{
				freq = new PropertyVO();
				freq.setPropertyId(frequency);
				freq.setPropertyValue(loss);

				List<Map<String, PropertyVO>> frequencyList = new ArrayList<>();
				Map<String, PropertyVO> frequencyMap = new HashMap<>();
				
				frequencyMap.put(freq.getPropertyId(), freq);

				if (port.getChildProperties() != null)
					frequencyList = port.getChildProperties();

				frequencyList.add(frequencyMap);
				port.setChildProperties(frequencyList);
			}


		}
		
		
		System.out.println(propertyMap);
	}
}
