package com.practice.Concept;
import java.util.*;

public class PropertyVO {

	private String propertyId;

	private String propertyValue;

	private List<Map<String, PropertyVO>> childProperties;

	public String getPropertyId() {
		return propertyId;
	}

	@Override
	public String toString() {
		return getPropertyValue()!= null?"[ propertyValue=" + propertyValue + ", childProperties="
				+ childProperties + "]":"childProperties="+ childProperties + "]";
	}

	public void setPropertyId(String propertyId) {
		this.propertyId = propertyId;
	}

	public String getPropertyValue() {
		return propertyValue;
	}

	public void setPropertyValue(String propertyValue) {
		this.propertyValue = propertyValue;
	}

	public List<Map<String, PropertyVO>> getChildProperties() {
		return childProperties;
	}

	public void setChildProperties(List<Map<String, PropertyVO>> childProperties) {
		this.childProperties = childProperties;
	}
	
	
}
