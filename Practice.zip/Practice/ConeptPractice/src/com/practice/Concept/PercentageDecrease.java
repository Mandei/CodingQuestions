package com.practice.Concept;

public class PercentageDecrease {
	static double a, b, c, d, e;
	static double j_initial, k_initial, l_initial, m_initial, n_initial;
	static double quantity[] = new double[5];
	static double rate[] = new double[5];

	public static void main(String[] args) {
		a = 921.25;
		b = 921.25;
		c = 92.13;
		d = 838.75;
		e = 22.50;

		quantity[0] = a;
		quantity[1] = b;
		quantity[2] = c;
		quantity[3] = d;
		quantity[4] = e;

		j_initial = 100;
		k_initial = 150;
		l_initial = 120;
		m_initial = 140;
		n_initial = 230;

		rate[0] = j_initial;
		rate[1] = k_initial;
		rate[2] = l_initial;
		rate[3] = m_initial;
		rate[4] = n_initial;
		
		
		int fixedrate[] = { 1, 1, 0, 0, 0 };

		
		double fixedSum = 0;
		double varSum = 0;

		for (int i = 0; i < 5; i++) {
			if (fixedrate[i] == 1)
				fixedSum += (quantity[i] * rate[i]);
			else
				varSum += (quantity[i] * rate[i]);
		}
		
		double ratio[]={0,0,0,0,0};
		
		for (int i = 0; i < 5; i++) {

			if (fixedrate[i] == 0) {
				ratio[i] = (rate[i]/100);
				System.out.print(ratio[i]+",");
			}
		}

		double fixedQuantitySum = 0;
		for (int i = 0; i < 5; i++) {
			if (fixedrate[i] == 0)
				fixedQuantitySum += (quantity[i]*ratio[i]);
		}

		System.out.println("\nFixed Sum:" + fixedSum + " Var Sum :" + varSum);
		
		double actualValue = 0;
		for (int i = 0; i < quantity.length; i++) {
			actualValue += (quantity[i] * rate[i]);

		}
		double desiredValue = round2point(actualValue * 0.7);
		System.out.println("Actual value:" + actualValue);
		double difference = actualValue - desiredValue;
		System.out.println("Actual-Desired<difference>:" + (difference));

		System.out.println("RateSum:" + fixedQuantitySum);
		double multiple = difference / Math.floor(fixedQuantitySum);
		System.out.println("Mulitple:" + (multiple));
		
		varSum = 0;
		for (int i = 0; i < 5; i++) {

			if (fixedrate[i] == 0) {
				rate[i]-=(Math.ceil(multiple*ratio[i]));
				varSum += (quantity[i] * rate[i]);
			}
		}
		
		System.out.println(
				"Desired value and(varSum + fixedSum)= " + desiredValue + " " + round2point(varSum + fixedSum));
		displayValue(rate);
		
	}

	static double round2point(double value) {
		return Math.round((value) * 100.0) / 100.0;
	}

	static void displayValue(double result[]) {

		for (int i = 0; i < quantity.length; i++)
			System.out.println("Result[" + i + "] = " + (result[i]));
	}
}
