package com.practice.swing;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;

import javax.swing.*;
import javax.swing.border.Border;  

public class JtabbedPractice {
	JFrame f;  
	
	JtabbedPractice(){  
	    	
		  f=new JFrame();
		  f.setSize(new Dimension(700,700));
		  f.setLayout( new GridBagLayout());
		  
		  JPanel pBorderPanel= new JPanel();
		  JPanel p2=new JPanel();
		  JPanel p3=new JPanel();
		  JTabbedPane tabbedpane=new JTabbedPane();
//		  tabbedpane.add("TabbedPane1",pBorderPanel);
//		  tabbedpane.add("visit",p2);  
//		  tabbedpane.add("help",p3); 
//		  tabbedpane.setLayout(new GridBagLayout()); 
		  
//		  f.add(tabbedpane);
		  JScrollPane tableScrollPane1 = new JScrollPane();
	      JTable protocolHeaderTable=new JTable();
	      
	      protocolHeaderTable.setPreferredSize( new Dimension( 100, 100));
	      protocolHeaderTable.setBorder(BorderFactory.createTitledBorder(  "table1"));
	      protocolHeaderTable.setAutoResizeMode( JTable.AUTO_RESIZE_OFF);
	      
	      
	      pBorderPanel.setLayout( new GridBagLayout());
	      pBorderPanel.setBorder(BorderFactory.createTitledBorder(  "Protocol data"));
	      pBorderPanel.setPreferredSize(new Dimension(500,500));

	      f.add( pBorderPanel, new GridBagConstraints( 0, 0, 0, 0, 1.0, 1.0, GridBagConstraints.CENTER,
	         GridBagConstraints.BOTH, new Insets( 5, 5, 5, 5), 0, 0));
	      
	      pBorderPanel.add( tableScrollPane1, new GridBagConstraints( 0, 0, 1, 1, 1.0, 1.0, GridBagConstraints.WEST,
	         GridBagConstraints.BOTH, new Insets(10, 10, 10, 10), 0, 0));
//	      tableScrollPane1.setPreferredSize( new Dimension( 650, 120));
	      tableScrollPane1.getViewport().add( protocolHeaderTable);
	      tableScrollPane1.setBorder( BorderFactory.createTitledBorder("Header Data"));
	      protocolHeaderTable.setSelectionMode( ListSelectionModel.MULTIPLE_INTERVAL_SELECTION);

	      JScrollPane tableScrollPane2 = new JScrollPane();
	      JTable antennaDataTable= new JTable();
	      
	      antennaDataTable.setPreferredSize( new Dimension( 100, 100));
	      antennaDataTable.setAutoResizeMode( JTable.AUTO_RESIZE_OFF);
	      

	      pBorderPanel.add( tableScrollPane2, new GridBagConstraints( 0, 1, 0, 0, 1.0, 1.0, GridBagConstraints.WEST,
	      GridBagConstraints.BOTH, new Insets(10, 10, 10, 10), 0, 0));
//	      tableScrollPane2.setPreferredSize( new Dimension( 650, 150));
	      tableScrollPane2.getViewport().add( antennaDataTable);
	      tableScrollPane2.setBorder( BorderFactory.createTitledBorder(  "Antenna Table"));
	      f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);  
	      f.setVisible(true); 
	      
	}  
	
	public static void main(String[] args) {  
	    new JtabbedPractice();  
	}
}
