package com.practice.swing;

import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;

import javax.swing.BorderFactory;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.ListSelectionModel;

public class MeasurementTABtesting {
	public static void main(String[] args) 
	{
		
		  JFrame f=new JFrame();
		  f.setSize(new Dimension(700,700));
		  f.setLayout( new GridBagLayout());
		  
		  JPanel pBorderPanel= new JPanel();
		  JPanel pBorderPanelProtocol=new JPanel();
		  JPanel pBorderPanelAntennaData=new JPanel();
		  
		  
		  JScrollPane tableScrollPane1 = new JScrollPane();
		  JScrollPane tableScrollPane2 = new JScrollPane();
		  
		  
		  JTable protocolHeaderTable=new JTable();
		  JTable antennaDataTable=new JTable();
	      

	      
	      protocolHeaderTable.setPreferredSize( new Dimension( 600, 150));
	      antennaDataTable.setPreferredSize( new Dimension( 800, 200));
	      pBorderPanel.setLayout( new GridBagLayout());
	      pBorderPanel.setBorder(BorderFactory.createTitledBorder(  "Protocol data"));
	      
	      
	      pBorderPanelProtocol.setLayout( new GridBagLayout());
	      pBorderPanelProtocol.setBorder(BorderFactory.createTitledBorder(  "Header data"));
	      pBorderPanelAntennaData.setLayout( new GridBagLayout());
	      pBorderPanelAntennaData.setBorder(BorderFactory.createTitledBorder(  "Antenna data"));
	      
//	      f.setLayout( new GridBagLayout());

	      f.add( pBorderPanel, new GridBagConstraints( 0, 0, 1, 1, 1.0, 1.0, GridBagConstraints.CENTER,
	         GridBagConstraints.BOTH, new Insets( 10, 10, 10, 10), 0, 0));

	      pBorderPanel.add( pBorderPanelProtocol, new GridBagConstraints( 0, 0, 1, 1, 1.0, 1.0, GridBagConstraints.CENTER,
	         GridBagConstraints.BOTH, new Insets( 0, 0, 10, 0), 0, 0));
	      pBorderPanelProtocol.add( protocolHeaderTable, new GridBagConstraints( 0, 0, 1, 1, 1.0, 1.0,
	         GridBagConstraints.WEST, GridBagConstraints.BOTH, new Insets( 0, 0, 10, 0), 0, 0));
	      
	      protocolHeaderTable.setPreferredSize( new Dimension( 800, 200));
	      protocolHeaderTable.setSelectionMode( ListSelectionModel.MULTIPLE_INTERVAL_SELECTION);

	      
	      pBorderPanel.add( pBorderPanelAntennaData, new GridBagConstraints( 0, 1, 1, 1, 1.0, 1.0,
	         GridBagConstraints.CENTER, GridBagConstraints.BOTH, new Insets( 10, 0, 0, 0), 0, 0));
	      pBorderPanelAntennaData.add( antennaDataTable, new GridBagConstraints( 0, 0, 1, 1, 1.0, 1.0,
	         GridBagConstraints.WEST, GridBagConstraints.BOTH, new Insets( 0, 0, 10, 0), 0, 0));
	      antennaDataTable.setPreferredSize( new Dimension( 800, 200));
	      antennaDataTable.setSelectionMode( ListSelectionModel.MULTIPLE_INTERVAL_SELECTION);

	      
	      f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);  
	      f.setVisible(true);
	}
}
