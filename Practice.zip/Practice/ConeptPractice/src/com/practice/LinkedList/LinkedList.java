package com.practice.LinkedList;

class Node {
	int data;
	Node next = null;

	Node(int data) {
		this.data = data;
	}
	
	Node(){
	
	}
	
	static Node addNode(Node head,int data) 
	{
		Node temp = new Node(data);
		head.next=temp;
		return temp;
	}
	
	static void display(Node head) 
	{
		while(head!=null) 
		{
			System.out.println(head.data +" "+head.next); 
			head=head.next; 
		}
	}
}

public class LinkedList {

	public static void main(String[] args) {

		Node n1 = new Node(2);
		Node n2 = new Node(3);
		Node n3 = new Node(5);
		Node n4 = new Node(4);
		Node n5 = new Node(7);
		Node n6 = new Node(6);
		n1.next = n2;
		n2.next = n3;
		n3.next = n4;
		n4.next = n5;
		n5.next = n6;
		Node.display(n1);
		
		Node head=new Node(1);
		head=Node.addNode(head,2);
		head=Node.addNode(head,3);
		head=Node.addNode(head,4);
//		Node.addNode(head,5);
		Node.display(head);
		
		

//		Node even=new Node(-1);
//		Node odd=new Node(-1);
//		Node curr=n1;
//		Node Oddhead=odd;
//		Node EvenHead=even;
//		
//		
//		
//		while(curr!=null)
//		{
//			Node temp=curr.next;
//			if(curr.data%2 == 0)
//			{
//				even.next=curr;
//				even=even.next;
//				even.next=null;
//			}
//			else 
//			{
//				odd.next=curr;
//				odd=odd.next;
//				odd.next=null;
//			}
//			curr=temp;
//		}
//		
//		even.next=Oddhead.next;
//		EvenHead=EvenHead.next;
//		
//		 
//		while(EvenHead!=null)
//		{
//			System.out.println(EvenHead.data);
//			EvenHead=EvenHead.next;
//		}
//		

//		Node prev,curr,even;
//		prev=n1;
//		curr=n1.next;
//		even=n1;
//
//		while(curr.next!=null) { 
//			
//		 System.out.println(curr.data );
//		 System.out.println(" Current Object : "+curr.toString().substring(24)
//		 +"\n Next Object : "+curr.next.toString().substring(24)); 
//		 
//		 if(curr.data %2 ==0)
//		 { 
//		 Node temp1=even; 
//		 Node temp2=curr; 
//		 Node temp3=prev;
//		  
//		 System.out.println("Before assignement");
//		 System.out.println("\n Curr Object : "+curr.toString().substring(24)+ "\n Curr.next Object : "+curr.next.toString().substring(24));
		 
//		 System.out.println(" Even Object : "+even.toString().substring(24)
//		 +"\n Curr Object : "+curr.toString().substring(24)+"\n Prev Object : "+prev.
//		 toString().substring(24));
//		 
//		 System.out.println(" temp1 Object : "+temp1.toString().substring(24)
//		 +"\n Temp2 Object : "+temp2.toString().substring(24)+"\n temp3 Object : "
//		 +temp3.toString().substring(24));
//		 System.out.println("\n Temp2 Object : "+temp2.toString().substring(24)+ "\n temp2.next Object : "+temp2.next.toString().substring(24));
//			
//		  even.next=temp2; 
//		  temp2.next=temp1.next; 
//		  temp3.next=curr.next;
//		  
//		  System.out.println("After assignement");
		  
//		  System.out.println(" Even Object : "+even.toString().substring(24)
//		  +"\n Curr Object : "+curr.toString().substring(24)+"\n Prev Object : "+prev.
//		  toString().substring(24));
//		  
//		  System.out.println(" temp1 Object : "+temp1.toString().substring(24)
//		  +"\n Temp2 Object : "+temp2.toString().substring(24)+"\n temp3 Object : "
//		  +temp3.toString().substring(24));
//		  System.out.println("\n Curr Object : "+curr.toString().substring(24)+ "\n Curr.next Object : "+curr.next.toString().substring(24));
//		  System.out.println("\n Temp2 Object : "+temp2.toString().substring(24)+ "\n temp2.next Object : "+temp2.next.toString().substring(24));
//			 
//		  
//		  prev=curr; 
//		  even=curr; 
//		  curr=curr.next;
//		  
//		  System.out.println("Even Object after update:-"+even.toString().substring(24)+"\n Curr Object after update : "+curr.toString().substring(24)+"\n Prev Object after update : "+prev.
//			  toString().substring(24)); 
//		  } 
//		 
//		 else 
//		 { 
//			 prev=curr; curr=curr.next; 
//			 
//		 } 
//		 
//		 }
		
//		while(n1.next!=null) 
//		 {
//		  System.out.println(n1.data +" "+n1.next); 
//		  n1=n1.next; 
//		 }
	
		 
//		System.out.println(n1.data +" "+n1.next);
//		System.out.println(n2.data +" "+n2.next);
//		System.out.println(n3.data +" "+n3.next);
//		System.out.println(n4.data +" "+n4.next);
//		System.out.println(n5.data +" "+n5.next);

}
}


