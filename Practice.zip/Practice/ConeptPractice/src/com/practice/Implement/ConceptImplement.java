package com.practice.Implement;

class base{
	  base()
	{
		System.out.println("Base class");
	}
}
class child extends base{
	child(){
		
		System.out.println("Child class");
	}
}
public class ConceptImplement {
	 public final static void main(String[] args) {
		System.out.println("Hello world");
		//base b=new base();
		child c=new child();
	}
}
