module InterviewConept {
	requires java.desktop;
}