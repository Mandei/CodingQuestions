package com.test;

public class ZeroOneArrays{

	public static void main(String[] args) {
		int a[] = {0,1,1,0,0,1,0};

		int first = 0;
		int last = a.length - 1;
		//----First Approach---
		while (first < last) {
			while (a[first] == 0 )
				first++;

			while (a[last] == 1 )
				last--;
			if (first < last) {
				a[first] = 0;
				a[last] = 1;
			}
		}
		//--- Second approach ------
		while (first < last) 
			if (a[first] == 1) 
				if (a[last] == 0) {
					a[first] = 0;
					a[last] = 1;
				} else
					last--;
			else
				first++;
		

		for (int val : a)
			System.out.println(val);
	}
}
